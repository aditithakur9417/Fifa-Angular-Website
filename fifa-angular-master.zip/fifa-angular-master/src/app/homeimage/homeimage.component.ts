import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeimage',
  templateUrl: './homeimage.component.html',
  styleUrls: ['./homeimage.component.css']
})
export class HomeimageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
