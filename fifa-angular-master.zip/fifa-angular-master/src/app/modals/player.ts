export class Player {
  age: string;
  club: string;
  name: string;
  image: string;
}
